let form1 = document.getElementById("form1");
let inp1 = document.getElementById("inp1");
let list1=document.getElementById("ul1")

form1.addEventListener("submit", e => {
    e.preventDefault()
    createList(inp1.value)
    inp1.value=""
    inp1.focus()
});

function createList(item){
    let html=`<li>This is : ${item}      <button class="item_btn" onclick="deleteItem(this)" >Delete</button></li></br>`
    list1.insertAdjacentHTML("beforeend",html)
}
function deleteItem(itemToDelete){
    itemToDelete.parentElement.remove()
}