function fadeIn(){
    $("#p1").fadeIn(2000);

}
function fadeOut(){
    $("#p1").fadeOut(2000); 
}
function fadeToggle(){
    $("#p1").fadeToggle(2000);
}

